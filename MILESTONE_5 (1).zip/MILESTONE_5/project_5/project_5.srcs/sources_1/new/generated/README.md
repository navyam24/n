# generated

Files in this folder are all generated, and should not be edited by hand. As a general principle, each file should give the path of the generator code used to generate itself.
